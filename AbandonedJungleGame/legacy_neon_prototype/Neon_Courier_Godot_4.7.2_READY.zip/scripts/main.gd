extends Node2D

const PlayerScript = preload("res://scripts/player.gd")
const EnemyScript = preload("res://scripts/enemy.gd")
const CrystalScript = preload("res://scripts/crystal.gd")
const ExitPortalScript = preload("res://scripts/exit_portal.gd")

var player: CharacterBody2D
var exit_portal: Area2D
var hud_layer: CanvasLayer
var cell_label: Label
var hp_label: Label
var score_label: Label
var objective_label: Label
var cells_collected := 0
var total_cells := 0
var score := 0
var game_started := false
var game_finished := false

func _ready() -> void:
	_setup_input()
	queue_redraw()
	_show_main_menu()

func _setup_input() -> void:
	_bind_key("move_left", KEY_A)
	_bind_key("move_left", KEY_LEFT)
	_bind_key("move_right", KEY_D)
	_bind_key("move_right", KEY_RIGHT)
	_bind_key("jump", KEY_SPACE)
	_bind_key("jump", KEY_W)
	_bind_key("jump", KEY_UP)
	_bind_key("attack", KEY_F)
	_bind_mouse("attack", MOUSE_BUTTON_LEFT)
	_bind_key("dash", KEY_SHIFT)

func _bind_key(action: StringName, keycode: Key) -> void:
	if not InputMap.has_action(action):
		InputMap.add_action(action)
	var event := InputEventKey.new()
	event.physical_keycode = keycode
	if not InputMap.action_has_event(action, event):
		InputMap.action_add_event(action, event)

func _bind_mouse(action: StringName, button: MouseButton) -> void:
	if not InputMap.has_action(action):
		InputMap.add_action(action)
	var event := InputEventMouseButton.new()
	event.button_index = button
	if not InputMap.action_has_event(action, event):
		InputMap.action_add_event(action, event)

func _draw() -> void:
	# Deep night sky
	draw_rect(Rect2(-800, -500, 5200, 1500), Color("071126"), true)
	# Moon / light source
	draw_circle(Vector2(410, 80), 85.0, Color(0.45, 0.7, 1.0, 0.12))
	draw_circle(Vector2(410, 80), 52.0, Color("b9e6ff"))
	# Distant skyline
	for i in range(22):
		var bx := float(i * 185 - 120)
		var h := float(160 + (i * 73) % 250)
		draw_rect(Rect2(bx, 610 - h, 120, h), Color("0e1a38"), true)
		for wy in range(3):
			for wx in range(2):
				if (i + wx + wy) % 3 == 0:
					draw_rect(Rect2(bx + 20 + wx * 48, 630 - h + wy * 48, 15, 24), Color(0.18, 0.75, 0.95, 0.35), true)
	# Ground haze
	draw_rect(Rect2(-500, 610, 4500, 250), Color("0a0f1e"), true)

func _show_main_menu() -> void:
	var layer := CanvasLayer.new()
	layer.name = "MenuLayer"
	add_child(layer)

	var shade := ColorRect.new()
	shade.color = Color(0.02, 0.03, 0.08, 0.88)
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	layer.add_child(shade)

	var panel := ColorRect.new()
	panel.color = Color(0.06, 0.09, 0.18, 0.96)
	panel.position = Vector2(300, 120)
	panel.size = Vector2(680, 470)
	layer.add_child(panel)

	var title := Label.new()
	title.text = "NEON COURIER"
	title.position = Vector2(370, 175)
	title.size = Vector2(540, 70)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 48)
	title.add_theme_color_override("font_color", Color("64edff"))
	layer.add_child(title)

	var subtitle := Label.new()
	subtitle.text = "Тестовый 2D-платформер на Godot 4"
	subtitle.position = Vector2(370, 245)
	subtitle.size = Vector2(540, 40)
	subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	subtitle.add_theme_font_size_override("font_size", 20)
	subtitle.add_theme_color_override("font_color", Color("f77fc8"))
	layer.add_child(subtitle)

	var desc := Label.new()
	desc.text = "Ты — курьер в ночном мегаполисе.\nСобери все энергоячейки, отбейся от дронов\nи доберись до портала на правом краю уровня."
	desc.position = Vector2(385, 305)
	desc.size = Vector2(510, 95)
	desc.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	desc.add_theme_font_size_override("font_size", 18)
	layer.add_child(desc)

	var controls := Label.new()
	controls.text = "A/D или ←/→ — идти   SPACE — прыжок\nF или ЛКМ — удар   SHIFT — рывок"
	controls.position = Vector2(385, 405)
	controls.size = Vector2(510, 65)
	controls.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	controls.add_theme_font_size_override("font_size", 17)
	controls.add_theme_color_override("font_color", Color("b8c7ea"))
	layer.add_child(controls)

	var start_button := Button.new()
	start_button.text = "НАЧАТЬ ЗАБЕГ"
	start_button.position = Vector2(505, 500)
	start_button.size = Vector2(270, 58)
	start_button.add_theme_font_size_override("font_size", 22)
	start_button.pressed.connect(func():
		layer.queue_free()
		_start_game()
	)
	layer.add_child(start_button)

func _start_game() -> void:
	game_started = true
	_build_level()
	_build_hud()

func _build_level() -> void:
	# Main continuous rooftop/ground segments.
	_add_platform(Vector2(300, 665), Vector2(600, 110))
	_add_platform(Vector2(860, 665), Vector2(320, 110))
	_add_platform(Vector2(1320, 665), Vector2(430, 110))
	_add_platform(Vector2(1880, 665), Vector2(450, 110))
	_add_platform(Vector2(2460, 665), Vector2(470, 110))
	_add_platform(Vector2(3090, 665), Vector2(620, 110))

	# Elevated rooftops.
	_add_platform(Vector2(690, 520), Vector2(220, 32))
	_add_platform(Vector2(1120, 430), Vector2(260, 32))
	_add_platform(Vector2(1580, 535), Vector2(220, 32))
	_add_platform(Vector2(2050, 440), Vector2(260, 32))
	_add_platform(Vector2(2590, 500), Vector2(240, 32))
	_add_platform(Vector2(2960, 390), Vector2(220, 32))
	_add_platform(Vector2(3330, 520), Vector2(210, 32))

	# Small stepping blocks.
	_add_platform(Vector2(440, 550), Vector2(110, 26))
	_add_platform(Vector2(1450, 390), Vector2(105, 26))
	_add_platform(Vector2(2290, 335), Vector2(110, 26))

	player = PlayerScript.new()
	player.position = Vector2(120, 590)
	add_child(player)
	player.died.connect(_on_player_died)
	player.health_changed.connect(_on_health_changed)

	var crystals := [
		Vector2(445, 505), Vector2(690, 472), Vector2(1110, 382),
		Vector2(1450, 345), Vector2(1580, 488), Vector2(2050, 393),
		Vector2(2290, 290), Vector2(2590, 453), Vector2(2960, 343),
		Vector2(3330, 473)
	]
	total_cells = crystals.size()
	for pos in crystals:
		_add_crystal(pos)

	_add_enemy(Vector2(850, 590), 760, 980)
	_add_enemy(Vector2(1370, 590), 1210, 1490)
	_add_enemy(Vector2(1760, 590), 1670, 2030)
	_add_enemy(Vector2(2070, 390), 1940, 2160)
	_add_enemy(Vector2(2670, 590), 2520, 2780)
	_add_enemy(Vector2(2990, 340), 2880, 3040)
	_add_enemy(Vector2(3240, 590), 3120, 3420)

	exit_portal = ExitPortalScript.new()
	exit_portal.position = Vector2(3460, 610)
	add_child(exit_portal)
	exit_portal.entered.connect(_on_level_complete)

func _add_platform(center: Vector2, size: Vector2) -> void:
	var body := StaticBody2D.new()
	body.position = center
	body.collision_layer = 1
	body.collision_mask = 0
	var collision := CollisionShape2D.new()
	var shape := RectangleShape2D.new()
	shape.size = size
	collision.shape = shape
	body.add_child(collision)

	var base := Polygon2D.new()
	base.polygon = PackedVector2Array([
		Vector2(-size.x / 2.0, -size.y / 2.0),
		Vector2(size.x / 2.0, -size.y / 2.0),
		Vector2(size.x / 2.0, size.y / 2.0),
		Vector2(-size.x / 2.0, size.y / 2.0)
	])
	base.color = Color("172441")
	body.add_child(base)

	var neon := Line2D.new()
	neon.points = PackedVector2Array([
		Vector2(-size.x / 2.0, -size.y / 2.0 + 1.0),
		Vector2(size.x / 2.0, -size.y / 2.0 + 1.0)
	])
	neon.width = 4.0
	neon.default_color = Color("4cdcff")
	body.add_child(neon)

	# Decorative vents/lights.
	var details := Node2D.new()
	body.add_child(details)
	for x in range(int(-size.x / 2.0) + 35, int(size.x / 2.0) - 20, 75):
		var light := Polygon2D.new()
		light.polygon = PackedVector2Array([
			Vector2(x, -size.y / 2.0 + 14), Vector2(x + 22, -size.y / 2.0 + 14),
			Vector2(x + 22, -size.y / 2.0 + 20), Vector2(x, -size.y / 2.0 + 20)
		])
		light.color = Color(0.95, 0.25, 0.68, 0.32)
		details.add_child(light)
	add_child(body)

func _add_crystal(pos: Vector2) -> void:
	var crystal := CrystalScript.new()
	crystal.position = pos
	crystal.collected.connect(_on_cell_collected)
	add_child(crystal)

func _add_enemy(pos: Vector2, left_bound: float, right_bound: float) -> void:
	var enemy := EnemyScript.new()
	enemy.position = pos
	enemy.setup(player, left_bound, right_bound)
	enemy.destroyed.connect(_on_enemy_destroyed)
	add_child(enemy)

func _build_hud() -> void:
	hud_layer = CanvasLayer.new()
	hud_layer.layer = 10
	add_child(hud_layer)

	var bar := ColorRect.new()
	bar.color = Color(0.03, 0.05, 0.11, 0.88)
	bar.position = Vector2(18, 16)
	bar.size = Vector2(560, 92)
	hud_layer.add_child(bar)

	hp_label = Label.new()
	hp_label.position = Vector2(36, 28)
	hp_label.add_theme_font_size_override("font_size", 24)
	hp_label.add_theme_color_override("font_color", Color("ff6a88"))
	hud_layer.add_child(hp_label)

	cell_label = Label.new()
	cell_label.position = Vector2(180, 28)
	cell_label.add_theme_font_size_override("font_size", 22)
	cell_label.add_theme_color_override("font_color", Color("66f5d1"))
	hud_layer.add_child(cell_label)

	score_label = Label.new()
	score_label.position = Vector2(390, 28)
	score_label.add_theme_font_size_override("font_size", 22)
	hud_layer.add_child(score_label)

	objective_label = Label.new()
	objective_label.position = Vector2(36, 65)
	objective_label.size = Vector2(525, 32)
	objective_label.add_theme_font_size_override("font_size", 16)
	objective_label.add_theme_color_override("font_color", Color("bac8ed"))
	hud_layer.add_child(objective_label)
	_update_hud()

func _update_hud() -> void:
	if not is_instance_valid(hp_label):
		return
	hp_label.text = "HP: " + "♥".repeat(maxi(player.hp, 0))
	cell_label.text = "Энергия: %d / %d" % [cells_collected, total_cells]
	score_label.text = "Очки: %d" % score
	objective_label.text = "Выход заблокирован — собери все ячейки" if cells_collected < total_cells else "Портал активен! Доберись до конца уровня →"

func _on_cell_collected(value: int) -> void:
	cells_collected += value
	score += 25
	if cells_collected >= total_cells and is_instance_valid(exit_portal):
		exit_portal.set_active(true)
	_update_hud()

func _on_enemy_destroyed(points: int) -> void:
	score += points
	_update_hud()

func _on_health_changed(_value: int) -> void:
	_update_hud()

func _on_player_died() -> void:
	if game_finished:
		return
	game_finished = true
	player.set_physics_process(false)
	_show_end_overlay(false)

func _on_level_complete() -> void:
	if game_finished:
		return
	game_finished = true
	player.set_physics_process(false)
	score += 500
	_update_hud()
	_show_end_overlay(true)

func _show_end_overlay(win: bool) -> void:
	var layer := CanvasLayer.new()
	layer.layer = 30
	add_child(layer)
	var shade := ColorRect.new()
	shade.color = Color(0.015, 0.02, 0.055, 0.91)
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	layer.add_child(shade)

	var title := Label.new()
	title.text = "ДОСТАВКА ВЫПОЛНЕНА" if win else "КУРЬЕР ВЫБЫЛ"
	title.position = Vector2(290, 230)
	title.size = Vector2(700, 70)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 42)
	title.add_theme_color_override("font_color", Color("61efff") if win else Color("ff6f91"))
	layer.add_child(title)

	var info := Label.new()
	info.text = "Финальный счёт: %d\nЯчеек собрано: %d / %d" % [score, cells_collected, total_cells]
	info.position = Vector2(390, 320)
	info.size = Vector2(500, 90)
	info.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	info.add_theme_font_size_override("font_size", 22)
	layer.add_child(info)

	var restart := Button.new()
	restart.text = "СЫГРАТЬ ЕЩЁ РАЗ"
	restart.position = Vector2(505, 450)
	restart.size = Vector2(270, 58)
	restart.add_theme_font_size_override("font_size", 20)
	restart.pressed.connect(func(): get_tree().reload_current_scene())
	layer.add_child(restart)
