extends Area2D

signal collected(value: int)

var base_y := 0.0
var t := 0.0
var value := 1

func _ready() -> void:
	collision_layer = 8
	collision_mask = 2
	monitoring = true
	base_y = position.y
	var shape_node := CollisionShape2D.new()
	var shape := CircleShape2D.new()
	shape.radius = 18.0
	shape_node.shape = shape
	add_child(shape_node)
	body_entered.connect(_on_body_entered)

func _process(delta: float) -> void:
	t += delta
	position.y = base_y + sin(t * 3.0) * 7.0
	rotation = sin(t * 1.8) * 0.12
	queue_redraw()

func _on_body_entered(body: Node) -> void:
	if body.collision_layer & 2:
		collected.emit(value)
		queue_free()

func _draw() -> void:
	var outer := PackedVector2Array([
		Vector2(0, -20), Vector2(14, -5), Vector2(9, 17),
		Vector2(0, 23), Vector2(-9, 17), Vector2(-14, -5)
	])
	draw_colored_polygon(outer, Color("43e6bf"))
	var inner := PackedVector2Array([
		Vector2(0, -13), Vector2(8, -2), Vector2(5, 10),
		Vector2(0, 14), Vector2(-5, 10), Vector2(-8, -2)
	])
	draw_colored_polygon(inner, Color("d4fff3"))
	draw_circle(Vector2.ZERO, 29.0, Color(0.3, 1.0, 0.85, 0.08))
