extends Area2D

signal entered

var active := false
var t := 0.0

func _ready() -> void:
	collision_layer = 16
	collision_mask = 2
	monitoring = true
	var shape_node := CollisionShape2D.new()
	var shape := RectangleShape2D.new()
	shape.size = Vector2(76, 116)
	shape_node.shape = shape
	shape_node.position = Vector2(0, -58)
	add_child(shape_node)
	body_entered.connect(_on_body_entered)

func set_active(value: bool) -> void:
	active = value
	queue_redraw()

func _process(delta: float) -> void:
	t += delta
	queue_redraw()

func _on_body_entered(body: Node) -> void:
	if active and (body.collision_layer & 2):
		entered.emit()

func _draw() -> void:
	var glow := Color("4cf4ff") if active else Color("526079")
	draw_rect(Rect2(-37, -116, 74, 116), Color(0.04, 0.07, 0.15, 0.72), true)
	draw_line(Vector2(-37, -116), Vector2(37, -116), glow, 5.0)
	draw_line(Vector2(-37, -116), Vector2(-37, 0), glow, 5.0)
	draw_line(Vector2(37, -116), Vector2(37, 0), glow, 5.0)
	if active:
		var pulse := 0.5 + sin(t * 4.0) * 0.18
		draw_circle(Vector2(0, -57), 26.0, Color(0.3, 0.95, 1.0, pulse))
		draw_circle(Vector2(0, -57), 14.0, Color(0.9, 1.0, 1.0, 0.9))
	else:
		draw_circle(Vector2(0, -57), 18.0, Color("2e3852"))
		draw_line(Vector2(-10, -57), Vector2(10, -57), Color("8790a2"), 4.0)
