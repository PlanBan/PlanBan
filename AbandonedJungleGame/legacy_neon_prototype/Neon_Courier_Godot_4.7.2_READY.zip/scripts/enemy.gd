extends CharacterBody2D

signal destroyed(points: int)

const GRAVITY := 1500.0
const WALK_SPEED := 90.0
const CHASE_SPEED := 155.0

var target: CharacterBody2D
var patrol_left := 0.0
var patrol_right := 0.0
var direction := -1
var hp := 2
var hit_flash := 0.0
var damage_cooldown := 0.0

func setup(target_player: CharacterBody2D, left_bound: float, right_bound: float) -> void:
	target = target_player
	patrol_left = left_bound
	patrol_right = right_bound

func _ready() -> void:
	collision_layer = 4
	collision_mask = 1
	floor_snap_length = 6.0
	var shape_node := CollisionShape2D.new()
	var shape := RectangleShape2D.new()
	shape.size = Vector2(38, 48)
	shape_node.shape = shape
	shape_node.position = Vector2(0, -24)
	add_child(shape_node)

func _physics_process(delta: float) -> void:
	if not is_on_floor():
		velocity.y += GRAVITY * delta

	damage_cooldown = maxf(0.0, damage_cooldown - delta)
	hit_flash = maxf(0.0, hit_flash - delta)
	modulate = Color(1.0, 0.65, 0.65) if hit_flash > 0.0 else Color.WHITE

	var desired_direction := direction
	var speed := WALK_SPEED
	if is_instance_valid(target):
		var dx := target.global_position.x - global_position.x
		var dy := absf(target.global_position.y - global_position.y)
		if absf(dx) < 430.0 and dy < 130.0:
			desired_direction = 1 if dx > 0.0 else -1
			speed = CHASE_SPEED

	if global_position.x <= patrol_left:
		desired_direction = 1
	elif global_position.x >= patrol_right:
		desired_direction = -1
	direction = desired_direction
	velocity.x = move_toward(velocity.x, float(direction) * speed, 700.0 * delta)
	move_and_slide()

	if is_instance_valid(target) and damage_cooldown <= 0.0:
		if global_position.distance_to(target.global_position) < 52.0:
			damage_cooldown = 1.0
			if target.has_method("take_damage"):
				target.take_damage(1, direction)

func take_hit(from_direction: int) -> void:
	hp -= 1
	hit_flash = 0.15
	velocity.x = 360.0 * from_direction
	velocity.y = -190.0
	if hp <= 0:
		destroyed.emit(100)
		queue_free()

func _draw() -> void:
	# Drone body
	draw_circle(Vector2(0, -30), 19.0, Color("622b7a"))
	draw_rect(Rect2(-20, -35, 40, 15), Color("9f48c8"), true)
	draw_rect(Rect2(-12, -34, 24, 8), Color("101a36"), true)
	draw_circle(Vector2(0, -30), 4.0, Color("ff5151"))
	# Rotors
	draw_line(Vector2(-17, -43), Vector2(-34, -50), Color("88e7ff"), 3.0)
	draw_line(Vector2(17, -43), Vector2(34, -50), Color("88e7ff"), 3.0)
	draw_line(Vector2(-43, -50), Vector2(-25, -50), Color("e8fbff"), 4.0)
	draw_line(Vector2(25, -50), Vector2(43, -50), Color("e8fbff"), 4.0)
	# Legs
	draw_line(Vector2(-9, -17), Vector2(-14, 0), Color("46385f"), 5.0)
	draw_line(Vector2(9, -17), Vector2(14, 0), Color("46385f"), 5.0)
