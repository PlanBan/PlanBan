extends CharacterBody2D

signal died
signal health_changed(value: int)

const SPEED := 280.0
const JUMP_VELOCITY := -540.0
const GRAVITY := 1500.0
const DASH_SPEED := 650.0
const DASH_DURATION := 0.14

var hp := 3
var facing := 1
var dash_time := 0.0
var dash_cooldown := 0.0
var attack_cooldown := 0.0
var attack_visual := 0.0
var invulnerability := 0.0
var spawn_position := Vector2.ZERO
var attack_area: Area2D

func _ready() -> void:
	collision_layer = 2
	collision_mask = 1
	floor_snap_length = 7.0
	spawn_position = global_position

	var body_shape := CollisionShape2D.new()
	var rect := RectangleShape2D.new()
	rect.size = Vector2(34, 54)
	body_shape.shape = rect
	body_shape.position = Vector2(0, -27)
	add_child(body_shape)

	attack_area = Area2D.new()
	attack_area.collision_layer = 0
	attack_area.collision_mask = 4
	attack_area.monitoring = true
	attack_area.position = Vector2(42, -29)
	var attack_shape_node := CollisionShape2D.new()
	var attack_shape := RectangleShape2D.new()
	attack_shape.size = Vector2(58, 54)
	attack_shape_node.shape = attack_shape
	attack_area.add_child(attack_shape_node)
	add_child(attack_area)

	var camera := Camera2D.new()
	camera.position = Vector2(170, -90)
	camera.position_smoothing_enabled = true
	camera.position_smoothing_speed = 7.0
	camera.limit_left = 0
	camera.limit_right = 3600
	camera.limit_top = -300
	camera.limit_bottom = 760
	add_child(camera)

func _physics_process(delta: float) -> void:
	if invulnerability > 0.0:
		invulnerability -= delta
		modulate.a = 0.45 if int(invulnerability * 16.0) % 2 == 0 else 1.0
	else:
		modulate.a = 1.0

	dash_cooldown = maxf(0.0, dash_cooldown - delta)
	attack_cooldown = maxf(0.0, attack_cooldown - delta)
	attack_visual = maxf(0.0, attack_visual - delta)
	if attack_visual > 0.0:
		queue_redraw()

	var input_dir := Input.get_axis("move_left", "move_right")
	if absf(input_dir) > 0.01:
		facing = 1 if input_dir > 0.0 else -1
		attack_area.position.x = 42.0 * facing

	if not is_on_floor():
		velocity.y += GRAVITY * delta
	else:
		if Input.is_action_just_pressed("jump"):
			velocity.y = JUMP_VELOCITY

	if Input.is_action_just_pressed("dash") and dash_cooldown <= 0.0:
		dash_time = DASH_DURATION
		dash_cooldown = 0.75

	if dash_time > 0.0:
		dash_time -= delta
		velocity.x = DASH_SPEED * facing
	else:
		velocity.x = move_toward(velocity.x, input_dir * SPEED, 1700.0 * delta)

	if Input.is_action_just_pressed("attack") and attack_cooldown <= 0.0:
		attack()

	move_and_slide()

	if global_position.y > 860.0:
		global_position = spawn_position
		velocity = Vector2.ZERO
		take_damage(1, -facing)

func attack() -> void:
	attack_cooldown = 0.32
	attack_visual = 0.16
	queue_redraw()
	for body in attack_area.get_overlapping_bodies():
		if body.has_method("take_hit"):
			body.take_hit(facing)

func take_damage(amount: int, knockback_direction: int = 1) -> void:
	if invulnerability > 0.0 or hp <= 0:
		return
	hp -= amount
	invulnerability = 0.85
	velocity = Vector2(330.0 * knockback_direction, -300.0)
	health_changed.emit(hp)
	if hp <= 0:
		died.emit()

func _draw() -> void:
	# Shadow. Godot 4.7+ has a built-in CanvasItem.draw_ellipse().
	draw_ellipse(Vector2(0, 2), 22.0, 7.0, Color(0.0, 0.0, 0.0, 0.25))
	# Boots
	draw_rect(Rect2(-14, -9, 11, 11), Color("26304f"))
	draw_rect(Rect2(3, -9, 11, 11), Color("26304f"))
	# Jacket/body
	draw_rect(Rect2(-16, -48, 32, 38), Color("263c66"), true)
	draw_rect(Rect2(-12, -44, 24, 28), Color("ff4fb3"), true)
	# Head / visor
	draw_circle(Vector2(0, -59), 13.5, Color("ffc88f"))
	draw_rect(Rect2(-14, -64, 28, 8), Color("102044"), true)
	draw_line(Vector2(-9, -60), Vector2(9, -60), Color("55e7ff"), 3.0)
	# Backpack battery
	draw_rect(Rect2(-23 if facing > 0 else 13, -43, 10, 24), Color("16213f"), true)
	draw_rect(Rect2(-21 if facing > 0 else 15, -39, 6, 10), Color("5cf2c2"), true)
	# Sword swipe
	if attack_visual > 0.0:
		var start := Vector2(12.0 * facing, -37)
		var finish := Vector2(58.0 * facing, -20)
		draw_line(start, finish, Color("f7f0a8"), 7.0)
		draw_circle(finish, 5.0, Color("ffffff"))

