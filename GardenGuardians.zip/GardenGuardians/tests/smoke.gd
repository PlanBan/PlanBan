extends SceneTree
## Run: godot --headless --path . --script res://tests/smoke.gd

var garden: Node2D
var failures = 0
var checks = 0

func _initialize() -> void:
	call_deferred("run")

func check(condition: bool, description: String) -> void:
	checks += 1
	if not condition:
		failures += 1
		push_error("FAIL: " + description)
	else:
		print("PASS: " + description)

func reset() -> void:
	garden.start_game()
	garden.rng.seed = 2026
	garden.wave_wait = 999.0
	garden.sound_enabled = false

func step(seconds: float) -> void:
	for i in range(int(ceil(seconds / 0.025))):
		garden.advance(0.025)

func run() -> void:
	var scene = load("res://scenes/Garden.tscn")
	garden = scene.instantiate()
	root.add_child(garden)
	await process_frame
	garden.set_process(false)
	garden.music.stop()
	reset()
	check(garden.cell_at(Vector2(200, 272)) == Vector2i(0, 0), "first grid cell maps correctly")
	check(garden.cell_at(Vector2(1135, 691)) == Vector2i(8, 4), "last grid cell maps correctly")
	check(garden.cell_at(Vector2(1136, 692)) == Vector2i(-1, -1), "outside border is rejected")
	check(garden.place(Vector2i(0, 2)), "a shooter can be planted")
	check(garden.sun == 100, "planting spends exactly 75 light")
	check(not garden.place(Vector2i(0, 2)), "an occupied cell rejects planting")
	check(not garden.place(Vector2i(1, 2)), "seed cooldown prevents immediate reuse")
	step(0.9)
	garden.sun = 0
	check(not garden.place(Vector2i(1, 2)), "insufficient funds reject planting")
	check(not garden.place(Vector2i(9, 2)), "out-of-bounds cell rejects planting")
	garden.selected = "shovel"
	check(garden.place(Vector2i(0, 2)) and garden.sun == 18 and garden.plants.is_empty(), "shovel removes plant and refunds 25 percent, rounded down")
	reset()
	garden.selected = "sunbell"
	garden.place(Vector2i(0, 0))
	step(1.1)
	check(garden.suns.size() == 1, "sunbell produces a collectible light orb")
	var orb: Vector2 = garden.suns[0].pos
	check(garden.collect_sun(orb) and garden.sun == 150, "click collects light and credits resources")
	check(not garden.collect_sun(orb), "collected light cannot be collected twice")
	garden.add_sun(Vector2(700, 500))
	step(13.1)
	var expired = true
	for drop in garden.suns:
		if drop.pos == Vector2(700, 500): expired = false
	check(expired, "uncollected light expires")
	reset()
	garden.place(Vector2i(0, 2))
	garden.spawn_enemy(2, "ghoul", 400.0)
	step(9.0)
	check(garden.enemies.is_empty() and garden.score == 10, "shooter projectiles kill a zombie in their lane")
	reset()
	garden.place(Vector2i(0, 2))
	garden.spawn_enemy(3, "ghoul", 600.0)
	step(2.0)
	check(garden.bullets.is_empty() and garden.enemies[0].hp == 5.0, "shooters ignore zombies in another lane")
	reset()
	garden.selected = "stump"
	garden.place(Vector2i(3, 1))
	var plant_center: Vector2 = garden.center(Vector2i(3, 1))
	garden.spawn_enemy(1, "brute", plant_center.x + 40)
	step(2.0)
	check(garden.enemies[0].x == plant_center.x + 40 and garden.plants[Vector2i(3, 1)].hp < 420.0, "shield stops the enemy while taking bite damage")
	step(16.0)
	check(not garden.plants.has(Vector2i(3, 1)), "zombie eventually destroys an undefended shield")
	reset()
	garden.spawn_enemy(4, "runner", 165.0)
	garden.spawn_enemy(4, "brute", 600.0)
	step(0.1)
	check(not garden.guards[4] and garden.enemies.is_empty() and garden.playing, "one-use robot clears its entire lane")
	garden.spawn_enemy(4, "ghoul", 165.0)
	step(0.1)
	check(garden.result == "defeat" and not garden.playing, "a second breach ends the game")
	reset()
	garden.paused = true
	var before: float = garden.clock
	step(5.0)
	check(garden.clock == before and not garden.place(Vector2i(0, 0)), "pause freezes simulation and planting")
	reset()
	check(garden.sun == 175 and garden.guards[4] and garden.result == "", "restart restores resources, robots and outcome")
	garden.wave_wait = 13.0
	garden.sun = 10000
	for row in range(5):
		for col in [3, 5, 7]:
			garden.cooldowns.sprout = 0.0
			garden.place(Vector2i(col, row))
	var saw_runner = false
	var saw_brute = false
	var saw_boss = false
	for tick in range(14000):
		garden.advance(0.025)
		for enemy in garden.enemies:
			saw_runner = saw_runner or enemy.kind == "runner"
			saw_brute = saw_brute or enemy.kind == "brute"
			saw_boss = saw_boss or enemy.kind == "boss"
		if not garden.playing: break
	check(saw_runner and saw_brute and saw_boss, "later waves introduce runners, armored zombies and the boss")
	check(garden.wave == 4 and garden.result == "victory", "all four generated waves can be completed")
	check(garden.score == 450, "full campaign awards points for all 36 enemies including the boss")
	print("RESULT: %d checks, %d failures" % [checks, failures])
	garden.queue_free()
	await process_frame
	quit(0 if failures == 0 else 1)
