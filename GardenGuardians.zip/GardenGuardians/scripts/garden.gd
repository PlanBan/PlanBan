extends Node2D
## All simulation uses advance(delta), so it can be validated without a display.

const BOARD = Rect2(200, 272, 936, 420)
const CELL = Vector2(104, 84)
const ROWS = 5
const COLS = 9
const TOTAL_WAVES = 4
const COSTS = {"sprout": 75, "sunbell": 50, "stump": 100}
const HEALTH = {"sprout": 110.0, "sunbell": 90.0, "stump": 420.0}
const INK = Color("223e38")
const CREAM = Color("fff8df")
const GOLD = Color("ffcb62")

var plants: Dictionary = {}
var enemies: Array[Dictionary] = []
var bullets: Array[Dictionary] = []
var suns: Array[Dictionary] = []
var sparks: Array[Dictionary] = []
var guards: Array[bool] = [true, true, true, true, true]
var cooldowns: Dictionary = {"sprout": 0.0, "sunbell": 0.0, "stump": 0.0}
var selected = "sprout"
var sun = 175
var score = 0
var wave = 0
var spawn_remaining = 0
var spawn_index = 0
var wave_wait = 13.0
var spawn_clock = 0.0
var sun_clock = 3.0
var clock = 0.0
var playing = false
var paused = false
var result = ""
var hint = "Посадите колокольчик: он приносит свет для новых защитников."
var hint_time = 0.0
var art: Dictionary = {}
var font: Font
var rng = RandomNumberGenerator.new()
var sfx: Dictionary = {}
var music: AudioStreamPlayer
var sound_enabled = true

func _ready() -> void:
	rng.randomize()
	font = ThemeDB.fallback_font
	for key in ["sprout", "sunbell", "stump", "ghoul", "runner", "brute", "guard"]:
		art[key] = load("res://assets/%s.svg" % key)
	for key in ["plant", "sun", "hit", "alarm"]:
		var player = AudioStreamPlayer.new()
		player.stream = load("res://audio/%s.wav" % key)
		player.volume_db = -14.0
		add_child(player)
		sfx[key] = player
	music = AudioStreamPlayer.new()
	music.stream = load("res://audio/garden_loop.wav")
	music.volume_db = -23.0
	add_child(music)
	music.finished.connect(func():
		if sound_enabled: music.play()
	)
	music.play()
	queue_redraw()

func start_game() -> void:
	plants.clear()
	enemies.clear()
	bullets.clear()
	suns.clear()
	sparks.clear()
	guards = [true, true, true, true, true]
	cooldowns = {"sprout": 0.0, "sunbell": 0.0, "stump": 0.0}
	sun = 175
	score = 0
	wave = 0
	spawn_remaining = 0
	spawn_index = 0
	wave_wait = 13.0
	spawn_clock = 0.0
	sun_clock = 2.0
	clock = 0.0
	selected = "sprout"
	playing = true
	paused = false
	result = ""
	hint = "Сначала посадите колокольчик, затем стрелка. Собирайте свет кликом!"
	hint_time = 7.0
	queue_redraw()

func center(cell: Vector2i) -> Vector2:
	return BOARD.position + Vector2(cell) * CELL + CELL * 0.5

func cell_at(point: Vector2) -> Vector2i:
	if not BOARD.has_point(point): return Vector2i(-1, -1)
	return Vector2i((point - BOARD.position) / CELL)

func notify(message: String) -> void:
	hint = message
	hint_time = 3.0

func play_fx(key: String) -> void:
	if sound_enabled and sfx.has(key): sfx[key].play()

func place(cell: Vector2i) -> bool:
	if not playing or paused or cell.x < 0 or cell.x >= COLS or cell.y < 0 or cell.y >= ROWS:
		return false
	if selected == "shovel":
		if not plants.has(cell): return false
		sun += int(COSTS[plants[cell].kind] / 4)
		plants.erase(cell)
		burst(center(cell), CREAM)
		play_fx("plant")
		return true
	if plants.has(cell):
		notify("Эта клетка уже занята.")
		return false
	if cooldowns[selected] > 0.0:
		notify("Семена ещё восстанавливаются.")
		return false
	if sun < COSTS[selected]:
		notify("Не хватает света. Соберите золотые огоньки!")
		return false
	sun -= COSTS[selected]
	plants[cell] = {"kind": selected, "hp": HEALTH[selected], "timer": 1.0 if selected == "sunbell" else 0.25, "flash": 0.0}
	cooldowns[selected] = 2.0 if selected == "stump" else 0.8
	burst(center(cell), Color("a8de86"))
	play_fx("plant")
	return true

func add_sun(position: Vector2, value: int = 25) -> void:
	suns.append({"pos": position, "age": 0.0, "value": value})

func collect_sun(point: Vector2) -> bool:
	if not playing or paused: return false
	for i in range(suns.size() - 1, -1, -1):
		if point.distance_to(suns[i].pos) < 32.0:
			sun += suns[i].value
			burst(suns[i].pos, GOLD)
			suns.remove_at(i)
			play_fx("sun")
			return true
	return false

func spawn_enemy(row: int, kind: String = "ghoul", x: float = 1210.0) -> void:
	var hp = 5.0
	var speed = 15.0
	if kind == "runner":
		hp = 3.0
		speed = 25.0
	elif kind == "brute":
		hp = 11.0
		speed = 11.0
	elif kind == "boss":
		hp = 22.0
		speed = 9.0
	enemies.append({"row": row, "x": x, "hp": hp, "max_hp": hp, "speed": speed, "kind": kind, "flash": 0.0, "biting": false})

func burst(position: Vector2, color: Color) -> void:
	for i in range(7):
		sparks.append({"pos": position, "vel": Vector2(rng.randf_range(-65, 65), rng.randf_range(-85, -15)), "life": 0.5, "color": color})

func _process(delta: float) -> void:
	if playing and not paused: advance(minf(delta, 0.05))
	queue_redraw()

func advance(delta: float) -> void:
	if not playing or paused: return
	clock += delta
	hint_time = maxf(0.0, hint_time - delta)
	for key in cooldowns: cooldowns[key] = maxf(0.0, cooldowns[key] - delta)
	sun_clock -= delta
	if sun_clock <= 0.0:
		sun_clock = 6.0
		add_sun(Vector2(rng.randf_range(240, 1080), rng.randf_range(292, 650)))
	for i in range(suns.size() - 1, -1, -1):
		suns[i].age += delta
		if suns[i].age > 13.0: suns.remove_at(i)
	for i in range(sparks.size() - 1, -1, -1):
		sparks[i].life -= delta
		sparks[i].pos += sparks[i].vel * delta
		sparks[i].vel.y += 180.0 * delta
		if sparks[i].life <= 0.0: sparks.remove_at(i)
	_update_waves(delta)
	_update_plants(delta)
	_update_bullets(delta)
	_update_enemies(delta)

func _update_waves(delta: float) -> void:
	if spawn_remaining > 0:
		spawn_clock -= delta
		if spawn_clock <= 0.0:
			var kind = "ghoul"
			if wave >= 2 and spawn_index % 4 == 2: kind = "runner"
			if wave >= 3 and spawn_index % 5 == 4: kind = "brute"
			if wave == TOTAL_WAVES and spawn_remaining == 1: kind = "boss"
			spawn_enemy((spawn_index * 3 + wave - 1) % ROWS, kind)
			spawn_remaining -= 1
			spawn_index += 1
			spawn_clock = 3.2 if wave < 3 else 2.5
	elif enemies.is_empty():
		if wave >= TOTAL_WAVES:
			finish("victory")
			return
		wave_wait -= delta
		if wave_wait <= 0.0:
			wave += 1
			spawn_remaining = [3, 7, 11, 15][wave - 1]
			spawn_clock = 0.0
			wave_wait = 6.0
			notify("Волна %d! Защитите все дорожки." % wave)
			play_fx("alarm")

func _update_plants(delta: float) -> void:
	for cell in plants:
		var plant: Dictionary = plants[cell]
		plant.flash = maxf(0.0, plant.flash - delta)
		plant.timer -= delta
		if plant.kind == "sunbell" and plant.timer <= 0.0:
			plant.timer = 8.0
			add_sun(center(cell) + Vector2(12, -18))
		elif plant.kind == "sprout" and plant.timer <= 0.0:
			for enemy in enemies:
				if enemy.row == cell.y and enemy.x > center(cell).x:
					bullets.append({"pos": center(cell) + Vector2(28, -5), "row": cell.y})
					plant.timer = 1.45
					plant.flash = 0.12
					break

func _update_bullets(delta: float) -> void:
	for i in range(bullets.size() - 1, -1, -1):
		var bullet: Dictionary = bullets[i]
		var old_x: float = bullet.pos.x
		bullet.pos.x += 340.0 * delta
		var hit = -1
		var nearest = INF
		for j in range(enemies.size()):
			var enemy: Dictionary = enemies[j]
			if enemy.row == bullet.row and enemy.hp > 0.0 and enemy.x >= old_x - 24 and enemy.x <= bullet.pos.x + 24 and enemy.x < nearest:
				hit = j
				nearest = enemy.x
		if hit >= 0:
			enemies[hit].hp -= 1.0
			enemies[hit].flash = 0.14
			burst(bullet.pos, Color("9ee4e5"))
			play_fx("hit")
			bullets.remove_at(i)
		elif bullet.pos.x > 1270.0:
			bullets.remove_at(i)

func _update_enemies(delta: float) -> void:
	for i in range(enemies.size() - 1, -1, -1):
		var enemy: Dictionary = enemies[i]
		if enemy.hp <= 0.0:
			burst(Vector2(enemy.x, center(Vector2i(0, enemy.row)).y), Color("beaed0"))
			score += 100 if enemy.kind == "boss" else 10
			enemies.remove_at(i)
			continue
		enemy.flash = maxf(0.0, enemy.flash - delta)
		enemy.biting = false
		var target = Vector2i(-1, -1)
		var rightmost = -INF
		for cell in plants:
			var px: float = center(cell).x
			if cell.y == enemy.row and enemy.x <= px + 45.0 and enemy.x >= px - 28.0 and px > rightmost:
				target = cell
				rightmost = px
		if target.x >= 0:
			enemy.biting = true
			plants[target].hp -= (40.0 if enemy.kind == "boss" else 24.0) * delta
			if plants[target].hp <= 0.0:
				burst(center(target), Color("adc788"))
				plants.erase(target)
		else:
			enemy.x -= enemy.speed * delta
		if enemy.x < BOARD.position.x - 30:
			if guards[enemy.row]:
				guards[enemy.row] = false
				for other in enemies:
					if other.row == enemy.row: other.hp = 0.0
				notify("Садовый робот очистил дорожку %d. Запасного больше нет!" % (enemy.row + 1))
				play_fx("alarm")
			else:
				finish("defeat")
				return

func finish(outcome: String) -> void:
	playing = false
	paused = false
	result = outcome
	play_fx("alarm")

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		match event.keycode:
			KEY_1: selected = "sprout"
			KEY_2: selected = "sunbell"
			KEY_3: selected = "stump"
			KEY_4: selected = "shovel"
			KEY_SPACE, KEY_ESCAPE:
				if playing: paused = not paused
			KEY_ENTER:
				if not playing: start_game()
				elif paused: paused = false
			KEY_R: start_game()
			KEY_M: toggle_sound()
	if event is InputEventMouseButton and event.pressed:
		if event.button_index == MOUSE_BUTTON_RIGHT:
			selected = "shovel"
			return
		if event.button_index != MOUSE_BUTTON_LEFT: return
		var point = get_global_mouse_position()
		if not playing or paused:
			if Rect2(410, 592, 460, 62).has_point(point):
				if paused: paused = false
				else: start_game()
			return
		if Rect2(920, 182, 112, 32).has_point(point):
			toggle_sound()
			return
		if Rect2(1044, 182, 170, 32).has_point(point):
			paused = true
			return
		var keys = ["sprout", "sunbell", "stump", "shovel"]
		for i in range(4):
			if card_rect(i).has_point(point):
				selected = keys[i]
				return
		if not collect_sun(point): place(cell_at(point))

func toggle_sound() -> void:
	sound_enabled = not sound_enabled
	if sound_enabled: music.play()
	else: music.stop()

func card_rect(index: int) -> Rect2:
	return Rect2(36 + index * 222, 124, 208 if index < 3 else 160, 98)

func box(rect: Rect2, color: Color, radius: int = 16, border: Color = Color.TRANSPARENT, thickness: int = 0) -> void:
	var style = StyleBoxFlat.new()
	style.bg_color = color
	style.set_corner_radius_all(radius)
	style.border_color = border
	style.set_border_width_all(thickness)
	draw_style_box(style, rect)

func label_at(text: String, pos: Vector2, size: int = 20, color: Color = INK) -> void:
	draw_string(font, pos, text, HORIZONTAL_ALIGNMENT_LEFT, -1, size, color)

func centered(text: String, y: float, size: int, color: Color = INK) -> void:
	var width = font.get_string_size(text, HORIZONTAL_ALIGNMENT_LEFT, -1, size).x
	label_at(text, Vector2((1280 - width) / 2, y), size, color)

func picture(key: String, position: Vector2, size: Vector2, tint: Color = Color.WHITE) -> void:
	draw_texture_rect(art[key], Rect2(position - size / 2, size), false, tint)

func _draw() -> void:
	if font == null: return
	draw_rect(Rect2(0, 0, 1280, 800), Color("e9eddf"))
	draw_rect(Rect2(0, 0, 1280, 101), Color("203f38"))
	draw_circle(Vector2(22, 24), 120, Color("294a40"))
	label_at("РОСА И НЕЖИТЬ", Vector2(36, 50), 32, CREAM)
	label_at("Маленький сад. Большая оборона.", Vector2(38, 78), 16, Color("b7d6c3"))
	box(Rect2(1010, 23, 232, 58), Color("ffce69"), 18)
	draw_sun(Vector2(1043, 52), 17)
	label_at(str(sun), Vector2(1074, 62), 30)
	label_at("СВЕТ", Vector2(1160, 58), 15)
	_draw_cards()
	label_at("ВАШ САД", Vector2(201, 253), 15, Color("698571"))
	label_at("9 клеток × 5 дорожек", Vector2(948, 253), 15, Color("698571"))
	box(Rect2(190, 262, 956, 440), Color("435e47"), 20)
	for row in range(ROWS):
		for col in range(COLS):
			var rect = Rect2(BOARD.position + Vector2(col, row) * CELL, CELL)
			var tile_color = Color("a3c582") if (row + col) % 2 == 0 else Color("95b977")
			box(rect.grow(-2), tile_color, 7)
			for blade in range(3):
				var p = rect.position + Vector2(19 + blade * 29, 66 + (col * 3 + blade * 7) % 11)
				draw_line(p, p + Vector2(3, -5), Color(0.32, 0.48, 0.29, 0.25), 1.5)
		label_at("0%d" % (row + 1), Vector2(43, center(Vector2i(0, row)).y + 6), 17, Color("718770"))
		if guards[row]:
			picture("guard", Vector2(133, center(Vector2i(0, row)).y), Vector2(74, 68))
		else:
			draw_arc(Vector2(133, center(Vector2i(0, row)).y), 23, 0, TAU, 30, Color("acb7a2"), 2)
			label_at("—", Vector2(124, center(Vector2i(0, row)).y + 6), 20, Color("98a591"))
	_draw_hover()
	for cell in plants:
		var plant: Dictionary = plants[cell]
		var pos = center(cell)
		draw_ellipse_shadow(pos + Vector2(0, 27), Vector2(34, 8))
		var bob = sin(clock * 2.0 + cell.x + cell.y) * 2.0
		picture(plant.kind, pos + Vector2(0, bob), Vector2(76, 76), Color(1.25, 1.25, 1.1) if plant.flash > 0 else Color.WHITE)
		if plant.hp < HEALTH[plant.kind]: health_bar(pos + Vector2(-26, 33), 52, plant.hp / HEALTH[plant.kind])
	for enemy in enemies:
		var pos = Vector2(enemy.x, center(Vector2i(0, enemy.row)).y)
		var big = enemy.kind == "boss"
		var kind: String = "brute" if big else enemy.kind
		draw_ellipse_shadow(pos + Vector2(0, 30), Vector2(28, 8))
		picture(kind, pos + Vector2(sin(clock * 5) * 2, sin(clock * 6 + enemy.row) * 2), Vector2(90, 94) if big else Vector2(70, 78), Color(1.3, 0.95, 0.85) if enemy.flash > 0 else Color.WHITE)
		if big: label_at("!", pos + Vector2(-4, -51), 20, Color("a95046"))
		if enemy.hp < enemy.max_hp: health_bar(pos + Vector2(-23, -41), 46, enemy.hp / enemy.max_hp)
	for bullet in bullets:
		draw_circle(bullet.pos + Vector2(-5, 0), 8, Color(0.75, 0.95, 0.91, 0.3))
		draw_circle(bullet.pos, 6, Color("d3f8e9"))
		draw_circle(bullet.pos + Vector2(2, -2), 2, Color.WHITE)
	for spark in sparks:
		var color: Color = spark.color
		color.a = clampf(spark.life * 2, 0, 1)
		draw_circle(spark.pos, 3.0, color)
	for drop in suns:
		draw_sun(drop.pos + Vector2(0, sin(clock * 3.0 + drop.age) * 3), 22, clampf(13.0 - drop.age, 0, 1))
	box(Rect2(36, 724, 1208, 49), CREAM, 13)
	label_at(hint if hint_time > 0 else "1–3: семена   ·   4 / ПКМ: лопата   ·   Пробел: пауза   ·   R: заново   ·   M: звук", Vector2(54, 755), 17)
	if not playing or paused: _draw_overlay()

func draw_ellipse_shadow(pos: Vector2, size: Vector2) -> void:
	draw_set_transform(pos, 0, Vector2(1, size.y / size.x))
	draw_circle(Vector2.ZERO, size.x, Color(0.15, 0.25, 0.17, 0.18))
	draw_set_transform(Vector2.ZERO)

func health_bar(pos: Vector2, width: float, ratio: float) -> void:
	box(Rect2(pos, Vector2(width, 5)), Color("456247"), 2)
	box(Rect2(pos, Vector2(width * clampf(ratio, 0, 1), 5)), Color("ffcf6e"), 2)

func draw_sun(pos: Vector2, radius: float, alpha: float = 1.0) -> void:
	draw_circle(pos, radius + 8, Color(1.0, 0.83, 0.35, alpha * 0.22))
	for i in range(8):
		var direction = Vector2.from_angle(float(i) * TAU / 8 + clock * 0.25)
		draw_line(pos + direction * (radius + 2), pos + direction * (radius + 6), Color(1, 0.75, 0.26, alpha), 3)
	draw_circle(pos, radius, Color(1, 0.8, 0.36, alpha))
	draw_circle(pos + Vector2(-radius * 0.2, -radius * 0.25), radius * 0.65, Color(1, 0.92, 0.61, alpha))

func _draw_cards() -> void:
	var keys = ["sprout", "sunbell", "stump", "shovel"]
	var titles = ["Росострел", "Колокольчик", "Пень-щит", "Лопата"]
	var notes = ["Стреляет каплями", "Приносит свет", "Задерживает врагов", "Убрать растение"]
	for i in range(4):
		var rect = card_rect(i)
		var active = selected == keys[i]
		box(rect, CREAM if active else Color("f8f7ed"), 16, Color("426f51") if active else Color("d2dbc7"), 3 if active else 1)
		label_at(str(i + 1), rect.position + Vector2(12, 23), 13, Color("81917b"))
		if i < 3:
			picture(keys[i], rect.position + Vector2(42, 57), Vector2(62, 62))
			label_at(titles[i], rect.position + Vector2(80, 30), 18)
			label_at(notes[i], rect.position + Vector2(80, 51), 11, Color("6d826b"))
			label_at("☀ %d" % COSTS[keys[i]], rect.position + Vector2(80, 80), 20, Color("a0702f"))
			if cooldowns[keys[i]] > 0:
				box(Rect2(rect.position + Vector2(8, 89), Vector2(192 * cooldowns[keys[i]] / (2.0 if i == 2 else 0.8), 4)), Color("70a469"), 2)
		else:
			label_at(titles[i], rect.position + Vector2(28, 37), 23)
			label_at(notes[i], rect.position + Vector2(15, 63), 13, Color("6d826b"))
			label_at("Возврат 25%", rect.position + Vector2(27, 83), 13, Color("a0702f"))
	label_at("ВОЛНА  %d / %d" % [wave, TOTAL_WAVES], Vector2(922, 149), 21)
	var status = "%d врагов в пути" % (spawn_remaining + enemies.size())
	if spawn_remaining == 0 and enemies.is_empty(): status = "Новая волна через %d с" % int(ceil(wave_wait))
	label_at(status, Vector2(922, 173), 14, Color("6d826b"))
	box(Rect2(920, 182, 112, 32), Color("d8e0cf"), 9)
	label_at("Звук: %s" % ("вкл" if sound_enabled else "выкл"), Vector2(932, 203), 13)
	box(Rect2(1044, 182, 170, 32), Color("d8e0cf"), 9)
	label_at("Пауза  [пробел]", Vector2(1056, 203), 13)

func _draw_hover() -> void:
	if not playing or paused: return
	var cell = cell_at(get_global_mouse_position())
	if cell.x < 0: return
	var can_place = not plants.has(cell) and selected != "shovel"
	box(Rect2(BOARD.position + Vector2(cell) * CELL, CELL).grow(-3), Color(1, 1, 0.8, 0.15), 8, CREAM, 2)
	if can_place:
		picture(selected, center(cell), Vector2(76, 76), Color(1, 1, 1, 0.45))

func _draw_overlay() -> void:
	draw_rect(Rect2(0, 0, 1280, 800), Color(0.08, 0.17, 0.14, 0.68))
	box(Rect2(280, 210, 720, 468), CREAM, 28)
	box(Rect2(518, 232, 244, 30), Color("dbe9cb"), 15)
	centered("САДОВАЯ ОБОРОНА", 253, 14, Color("4a7055"))
	var title = "РОСА И НЕЖИТЬ"
	var sub = "Посадите защитников. Соберите свет. Переживите ночь."
	if paused:
		title = "ТИШИНА В САДУ"
		sub = "Игра на паузе. Ваш сад подождёт."
	elif result == "victory":
		title = "САД СПАСЁН!"
		sub = "Все 4 волны отражены. Очки: %d" % score
	elif result == "defeat":
		title = "НЕЖИТЬ ПРОБРАЛАСЬ"
		sub = "Очки: %d. Больше стрелков и колокольчиков — и получится!" % score
	centered(title, 308, 36)
	centered(sub, 340, 17, Color("6b7e65"))
	picture("sunbell", Vector2(442, 402), Vector2(88, 88))
	picture("sprout", Vector2(640, 400), Vector2(92, 92))
	picture("ghoul", Vector2(838, 400), Vector2(82, 92))
	centered("Колокольчик даёт свет · Росострел бьёт по своей дорожке", 474, 18)
	centered("Пень держит удар · Золотые огоньки собираются кликом", 505, 18)
	centered("У каждой дорожки есть один спасательный робот", 536, 16, Color("748568"))
	box(Rect2(410, 592, 460, 62), Color("2b624b"), 16)
	centered("ПРОДОЛЖИТЬ" if paused else ("ЕЩЁ ОДИН САД" if result != "" else "ЗАЩИТИТЬ САД"), 632, 24, CREAM)
